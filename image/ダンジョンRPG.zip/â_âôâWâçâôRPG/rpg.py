import pygame
from pygame.locals import *
import sys

WIDTH = 600  # 幅
HEIGHT = 400  # 高さ

screen = pygame.display.set_mode((WIDTH, HEIGHT), 0, 32)  # 画面サイズ指定
scene = 0  # 0:初期場面 1:1場面 2:??

# 背景画像の取得
bg = pygame.image.load("images/bg.jpg").convert_alpha()
bg = pygame.transform.scale(bg, (600, 400))  # 600 * 400に画像を縮小
rect_bg = bg.get_rect()

# ドア画像の取得
sign = pygame.image.load("images/sign.png").convert_alpha()
sign = pygame.transform.scale(sign, (60, 70))
rect_sign = sign.get_rect()

# プレイヤー画像の取得
player = pygame.image.load("images/player.png").convert_alpha()
player = pygame.transform.scale(player, (80, 80))  # 600 * 400に画像を縮小
rect_player = player.get_rect()


def main():
    global screen
    pygame.init()  # pygame初期化
    pygame.key.set_repeat(500, 30)  # 操作キーを押しっぱなしで移動できるための準備(delay, interval)
    rect_player.center = (550, 350)  # プレイヤー画像の初期位置

    visible = False

    while (1):
        pygame.display.update()  # 画面更新
        pygame.time.wait(30)  # 更新時間間隔

        screen.blit(bg, rect_bg)  # 背景画像の描画

        if scene == 0:
            firstStageDisplay()
        elif scene == 1:
            secondStateDisplay()

        screen.blit(player, rect_player)  # プレイヤー画像の描画

        if visible and rect_player.colliderect(rect_sign):  # 看板とプレイヤーが接触した場合
            problemDisplay()  # 問題を提示
        else:
            visible = False

        # 終了用のイベント処理
        for event in pygame.event.get():
            if event.type == QUIT:  # 閉じるボタンが押されたとき
                pygame.quit()  # pygameの終了
                sys.exit()
            if event.type == KEYDOWN:  # キーを押したとき
                pygame.key.get_repeat()  # 操作キーを長押しで移動可能にする
                if event.key == K_LEFT:
                    rect_player.move_ip(-15, 0)
                if event.key == K_RIGHT:
                    rect_player.move_ip(15, 0)
                if event.key == K_UP:
                    visible = True


# 問題文を表示する関数
def problemDisplay():
    letter = pygame.image.load("images/letter.png").convert_alpha()  # 問題文の取得
    letter = pygame.transform.scale(letter, (WIDTH*2/3, HEIGHT*2/3))  # size変更
    rect_letter = letter.get_rect()
    rect_letter.center = (WIDTH/2, HEIGHT*2/5)  # 問題文の初期位置

    if scene == 0:
        screen.blit(letter, rect_letter)  # 問題文を描画する


f_once = True
def firstStageDisplay():
    global scene, f_once
    # player位置リセット
    if f_once:
        if rect_player.left < -40:
            rect_player.center = (550, 350)
        if rect_player.right > WIDTH + 40:
            rect_player.center = (50, 350)
        f_once = False

    rect_sign.center = (500, 355)  # 看板画像の初期位置
    screen.blit(sign, rect_sign)  # 看板画像の描画

    
    # 画面端にきたら場面を変える
    if rect_player.left < -40 or rect_player.right > WIDTH + 40:
        scene = 1
        f_once = True


s_once = True
def secondStateDisplay():  # scene=1のときの場面
    global scene, s_once  # 無限ループ防止対策
    # player位置リセット
    if s_once:
        if rect_player.left < -40:
            rect_player.center = (550, 350)
        if rect_player.right > WIDTH + 40:
            rect_player.center = (50, 350)
        s_once = False

    # 画面端にきたら場面を変える
    if rect_player.left < -40 or rect_player.right > WIDTH + 40:
        scene = 0
        s_once = True


if __name__ == '__main__':
    main()
